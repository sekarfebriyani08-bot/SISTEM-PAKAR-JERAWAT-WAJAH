const gejala = [
  { kode: "Ge01", text: "Apakah kamu mengalami jerawat?" },
  { kode: "Ge02", text: "Apakah muncul pustula?" },
  { kode: "Ge03", text: "Apakah muncul nodul?" },
  { kode: "Ge04", text: "Apakah terdapat infeksi dan peradangan?" },
  { kode: "Ge05", text: "Apakah produksi sebum berlebih?" },
  { kode: "Ge06", text: "Apakah pori-pori tersumbat?" },
  { kode: "Ge07", text: "Apakah kulit berminyak?" },
  { kode: "Ge08", text: "Apakah kulit kemerahan?" },
  { kode: "Ge09", text: "Apakah terasa nyeri saat disentuh?" },
  { kode: "Ge10", text: "Apakah terasa panas atau terbakar?" },
  { kode: "Ge11", text: "Apakah meninggalkan bekas jerawat?" },
  { kode: "Ge12", text: "Apakah usia kamu 30–40 tahun?" },
  { kode: "Ge13", text: "Apakah kulit mengalami iritasi?" },
  { kode: "Ge14", text: "Apakah sensitif terhadap matahari?" },
  { kode: "Ge15", text: "Apakah produksi sebum meningkat?" },
  { kode: "Ge16", text: "Apakah muncul di wajah, dada, atau punggung?" },
  { kode: "Ge17", text: "Apakah usia 40–60 tahun?" },
  { kode: "Ge18", text: "Apakah jerawat sulit disembuhkan?" },
  { kode: "Ge19", text: "Apakah meninggalkan bekas luka parah?" },
  { kode: "Ge20", text: "Apakah terjadi peradangan kronis?" },
  { kode: "Ge21", text: "Apakah jarang sembuh total?" },
  { kode: "Ge22", text: "Apakah kamu wanita dewasa?" },
  { kode: "Ge23", text: "Apakah jerawat muncul di dagu atau rahang?" },
  { kode: "Ge24", text: "Apakah dipengaruhi hormon?" },
  { kode: "Ge25", text: "Apakah terdapat komedo terbuka?" },
  { kode: "Ge26", text: "Apakah terdapat komedo tertutup?" },
  { kode: "Ge27", text: "Apakah jerawat ringan?" },
  { kode: "Ge28", text: "Apakah usia remaja?" }
];

const rules = {
  "Acne Vulgaris": ["Ge01","Ge02","Ge03","Ge04","Ge05","Ge06"],
  "Rosacea": ["Ge01","Ge02","Ge07","Ge08","Ge09","Ge10","Ge11","Ge12"],
  "Perioral Dermatitis": ["Ge01","Ge02","Ge13","Ge14","Ge15","Ge16"],
  "Hidradenitis Suppurativa": ["Ge01","Ge02","Ge17","Ge18","Ge19","Ge20","Ge21"],
  "Hormonal Acne": ["Ge01","Ge22","Ge23","Ge24"],
  "Acne Comedonica": ["Ge01","Ge02","Ge13","Ge25","Ge26"],
  "Acne Juvenile": ["Ge01","Ge02","Ge27","Ge28"]
};

let index = 0;
let jawaban = [];

const pertanyaanDiv = document.getElementById("pertanyaan");

function tampilkanPertanyaan() {
  if (index < gejala.length) {
    pertanyaanDiv.innerHTML = gejala[index].text;
  } else {
    diagnosa();
  }
}

function jawab(ya) {
  if (ya) jawaban.push(gejala[index].kode);
  index++;
  tampilkanPertanyaan();
}

function diagnosa() {
  let hasil = "Tidak dapat ditentukan";

  for (let penyakit in rules) {
    if (rules[penyakit].every(g => jawaban.includes(g))) {
      hasil = penyakit;
      
      break;
    }
  }

  pertanyaanDiv.innerHTML = "";
  document.getElementById("hasil").innerHTML =
    "Hasil Diagnosa:<br><span style='color:#6a1b3f'>" + hasil + "</span>";
}

function diagnosa() {
  let hasil = "Tidak dapat ditentukan";

  for (let penyakit in rules) {
    if (rules[penyakit].every(g => jawaban.includes(g))) {
      hasil = penyakit;
      break;
    }
  }

  // HILANGKAN PERTANYAAN
  document.getElementById("pertanyaan").innerHTML = "";

  // SEMBUNYIKAN TOMBOL YA / TIDAK
  document.getElementById("tombolJawaban").style.display = "none";

  // TAMPILKAN HASIL
  document.getElementById("hasil").innerHTML =
    "Hasil Diagnosa:<br><span style='color:#6a1b3f'>" + hasil + "</span>";

  // TAMPILKAN MENU BALIK
  document.getElementById("menuBalik").style.display = "block";
}




tampilkanPertanyaan();
